# Mosaic NADH extraction example

This example contains 25 fields of view, Mosaic01 through Mosaic25, for FLIM Playground's image-based Data Extraction workflow.

## Files

- 25 SDT decay files: Mosaic01.sdt through Mosaic25.sdt.
- 25 matching cell masks: Mosaic01_Ch2_summed_cellpose.tiff through Mosaic25_Ch2_summed_cellpose.tiff.
- One shared instrument response: nadh_irf.txt.
- SHA256SUMS lists the checksum of each input file.

Keep the decay files, masks, and IRF together. Each SDT contains one 512 x 512 image channel, with 256 time bins over a 12.5 ns period. The `Ch2` text in the mask filename is part of its saved name; configure one channel in FLIM Playground.

## Configure and extract

Use a local FLIM Playground installation. In Home, create an extraction profile with:

| Setting | Value |
|---|---|
| Number of channels | 1 |
| Channel name | NADH |
| Imaging modality | FLIM |
| FLIM input format | Decay (3/4D) |
| Feature extractors | Lifetime fit; Lifetime fit free |
| Number of components | 2 |
| Laser rate | 0.08 GHz |
| Fit free calibration method | IRF |
| Decay suffix | .sdt |
| Mask suffix | _Ch2_summed_cellpose.tiff |
| IRF suffix | nadh_irf.txt |
| Unique cell identifier | cell_id |
| FOV column name | image_name |

Click Update Configuration. In Data Extraction > FOV Metadata Extraction, enter the full path to this folder, check the 25 fields of view, and export the metadata CSV.

Switch to Numeric Feature Extraction. Start with MLE, Hybrid, two components, Fix the Shift selected, and time gates 0-256. Click Optimize for Shifts and inspect the fitted decay for Mosaic16. Confirm the time gates and shift, then choose Local for faster cell-level fitting or retain Hybrid before clicking Confirm and Start. Save the updated metadata if you want to reuse the calibration.

When extraction finishes, the app saves `single_cell_features_<timestamp>.csv` in this same `3d_decay_1channel` folder, beside the FOV metadata CSV. Upload the single-cell feature CSV in Data Analysis with Use Dataset from Data Extraction checked. Color by image_name to compare fields of view. The Mosaic names identify fields of view; they do not encode treatment labels.

See the manual's [Numerical Feature Extraction chapter](https://skalalab.github.io/flim_playground_doc/numerical_feature_extraction.html) for more detail on extraction and calibration.

## Dataset collection

This is the `3d_decay_1channel` example from the FLIM Playground example-data collection. The archive preserves the original input bytes and includes only the raw decay files, their masks, and the shared IRF; it does not include the optional SPCImage pre-fitted outputs.

Dataset citation, as listed by FLIM Playground: Zhao, W., Samimi, K., Skala, M. C., & Datta, R. (2026). *Example and validation datasets for FLIM Playground* [Data set]. Zenodo. https://doi.org/10.5281/zenodo.19774943
